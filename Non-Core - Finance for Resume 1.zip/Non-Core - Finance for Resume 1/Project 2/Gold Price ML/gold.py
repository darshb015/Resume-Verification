import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.ensemble import RandomForestRegressor
from sklearn import metrics

# -------------------------------
# 1. Load the data
# -------------------------------
gold_data = pd.read_csv(r'Stock and Gold\gld_price_data.csv')

# Convert Date to datetime for future time-based analysis
gold_data['Date'] = pd.to_datetime(gold_data['Date'])

# -------------------------------
# 2. Quick data overview
# -------------------------------
print(gold_data.info())
print(gold_data.isnull().sum())   # check for missing values
print(gold_data.describe())       # basic statistics

# -------------------------------
# 3. Correlation analysis (ignore Date column)
# -------------------------------
correlation = gold_data.corr(numeric_only=True)

plt.figure(figsize=(8, 8))
sns.heatmap(correlation, cbar=True, square=True, fmt='.1f',
            annot=True, annot_kws={'size': 8}, cmap='Blues')
plt.title("Feature Correlation Heatmap")
plt.show()

print("\nCorrelation with GLD:\n", correlation['GLD'])

# -------------------------------
# 4. Distribution of GLD prices
# -------------------------------
sns.histplot(gold_data['GLD'], color='green', kde=True)
plt.title("GLD Price Distribution")
plt.show()

# -------------------------------
# 5. Prepare features (X) and target (Y)
# -------------------------------
X = gold_data.drop(['Date', 'GLD'], axis=1)
Y = gold_data['GLD']

print("\nFeatures (X):\n", X.head())
print("\nTarget (Y):\n", Y.head())

# -------------------------------
# 6. Train-test split
# -------------------------------
X_train, X_test, Y_train, Y_test = train_test_split(X, Y,
                                                    test_size=0.2,
                                                    random_state=2)

# -------------------------------
# 7. Hyperparameter tuning with GridSearchCV
# -------------------------------
param_grid = {
    'n_estimators': [100, 200, 300],
    'max_depth': [None, 5, 10, 15],
    'min_samples_split': [2, 5, 10]
}

grid_search = GridSearchCV(estimator=RandomForestRegressor(random_state=2),
                           param_grid=param_grid,
                           scoring='r2',
                           cv=3,
                           n_jobs=-1,
                           verbose=1)

grid_search.fit(X_train, Y_train)

print("\nBest Parameters from GridSearchCV:", grid_search.best_params_)

# -------------------------------
# 8. Train model with best parameters
# -------------------------------
best_model = grid_search.best_estimator_

# Prediction
test_data_prediction = best_model.predict(X_test)

# -------------------------------
# 9. Model evaluation
# -------------------------------
error_score = metrics.r2_score(Y_test, test_data_prediction)
print("R squared error:", error_score)

# -------------------------------
# 10. Visualization: Actual vs Predicted
# -------------------------------
plt.figure(figsize=(10, 6))
plt.plot(list(Y_test), color='blue', label='Actual Value')
plt.plot(test_data_prediction, color='green', label='Predicted Value')
plt.title('Actual Price vs Predicted Price')
plt.xlabel('Number of values')
plt.ylabel('GLD Price')
plt.legend()
plt.show()
