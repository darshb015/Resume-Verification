import pandas as pd
import numpy as np
from statsmodels.tsa.stattools import coint
from itertools import combinations
import time
from tqdm import tqdm
from colorama import Fore, Style, init

# Initialize colorama for colored output
init(autoreset=True)

# ======================
# 1. Load Excel Data
# ======================
def load_data(file_path):
    """Load Excel file with dates in the first column and stocks in the rest."""
    print(Fore.CYAN + "\n⏳ Loading data..." + Style.RESET_ALL)
    start_time = time.time()
    
    try:
        data = pd.read_excel(
            file_path, 
            index_col=0,  # First column = dates
            parse_dates=True
        )
        # Drop empty rows/columns and fill missing values
        data = data.dropna(axis=1, how='all').dropna(axis=0, how='all')
        data = data.ffill().bfill()  # Forward and backward fill
        
        load_time = time.time() - start_time
        print(Fore.GREEN + f"✅ Data loaded successfully! ({len(data.columns)} stocks, {len(data)} time periods)" + 
              Fore.YELLOW + f" [Time: {load_time:.2f}s]")
        return data
    
    except Exception as e:
        print(Fore.RED + f"❌ Error loading file: {e}")
        return None

# ======================
# 2. Pair Selection Logic
# ======================
def find_pairs(data, min_correlation=0.8, max_pvalue=0.05):
    """
    Find cointegrated stock pairs with high correlation.
    Returns DataFrame sorted by correlation and p-value.
    """
    if data is None:
        return None
    
    stocks = data.columns
    pairs = []
    total_pairs = len(list(combinations(stocks, 2)))
    
    print(Fore.CYAN + f"\n🔍 Analyzing {total_pairs:,} possible pairs..." + Style.RESET_ALL)
    print(Fore.LIGHTBLUE_EX + f"   - Minimum correlation threshold: {min_correlation}")
    print(Fore.LIGHTBLUE_EX + f"   - Maximum p-value threshold: {max_pvalue}")
    
    # Precompute correlations (shows progress)
    print(Fore.MAGENTA + "\n📊 Calculating correlation matrix..." + Style.RESET_ALL)
    corr_matrix = data.corr()
    
    # Initialize progress bar
    pbar = tqdm(total=total_pairs, desc="Analyzing pairs", unit="pair", 
                bar_format="{l_bar}{bar}| {n_fmt}/{total_fmt} [{elapsed}<{remaining}]")
    
    valid_pairs = 0
    start_time = time.time()
    
    # Iterate through all unique pairs
    for (i, stock1), (j, stock2) in combinations(enumerate(stocks), 2):
        if i >= j:  # Skip duplicates (A-B vs B-A)
            continue
        
        # Update progress bar
        pbar.update(1)
        
        # Skip low-correlation pairs early (for efficiency)
        corr = corr_matrix.iloc[i, j]
        if corr < min_correlation:
            continue
        
        # Check cointegration
        _, pvalue, _ = coint(data[stock1], data[stock2])
        if pvalue < max_pvalue:
            pairs.append({
                'Stock1': stock1,
                'Stock2': stock2,
                'Correlation': corr,
                'Cointegration_PValue': pvalue
            })
            valid_pairs += 1
    
    pbar.close()
    analysis_time = time.time() - start_time
    
    print(Fore.GREEN + f"\n🎉 Found {valid_pairs} valid pairs!" + 
          Fore.YELLOW + f" [Time: {analysis_time:.2f}s]")
    
    if valid_pairs == 0:
        print(Fore.RED + "⚠️ No valid pairs found. Try lowering correlation/p-value thresholds.")
        return None
    
    # Convert to DataFrame and sort
    pairs_df = pd.DataFrame(pairs)
    return pairs_df.sort_values(
        by=['Correlation', 'Cointegration_PValue'], 
        ascending=[False, True]
    )

# ======================
# 3. Run the Analysis
# ======================
if __name__ == "__main__":
    print(Fore.BLUE + Style.BRIGHT + "\n📈 PAIR TRADING ANALYSIS TOOL" + Style.RESET_ALL)
    print(Fore.LIGHTBLUE_EX + "="*50)
    
    # Replace with your Excel file path
    FILE_PATH = r"Main\Downloads\Combined Nifty100 Stocks Data.xlsx"
    
    data = load_data(FILE_PATH)
    
    if data is not None:
        pairs_df = find_pairs(
            data,
            min_correlation=0.8,  # Adjust thresholds as needed
            max_pvalue=0.05
        )
        
        if pairs_df is not None:
            # Save results
            output_file = r"Main\Downloads\pair_trading_candidates.csv"
            pairs_df.to_csv(output_file, index=False)
            print(Fore.GREEN + f"\n💾 Results saved to '{output_file}'")
            
            # Print top 20 pairs in a nice table format
            print(Fore.CYAN + "\n🏆 TOP 20 PAIR TRADING CANDIDATES:" + Style.RESET_ALL)
            print(Fore.LIGHTBLUE_EX + "-"*85)
            print(f"{'Stock 1':<15}{'Stock 2':<15}{'Correlation':<15}{'Cointegration (p-value)':<15}")
            print(Fore.LIGHTBLUE_EX + "-"*85)
            
            for i, row in pairs_df.head(20).iterrows():
                correlation_color = Fore.GREEN if row['Correlation'] > 0.9 else Fore.YELLOW if row['Correlation'] > 0.8 else Fore.RED
                pvalue_color = Fore.GREEN if row['Cointegration_PValue'] < 0.01 else Fore.YELLOW if row['Cointegration_PValue'] < 0.05 else Fore.RED
                
                print(f"{row['Stock1']:<15}{row['Stock2']:<15}" +
                      f"{correlation_color}{row['Correlation']:.4f}{Style.RESET_ALL:<15}" +
                      f"{pvalue_color}{row['Cointegration_PValue']:.6f}{Style.RESET_ALL}")
            
            print(Fore.LIGHTBLUE_EX + "-"*85)
            print(Fore.YELLOW + f"\nℹ️ Legend: " + 
                  Fore.GREEN + "Excellent " + 
                  Fore.YELLOW + "Good " + 
                  Fore.RED + "Marginal")
    
    print(Fore.LIGHTBLUE_EX + "\n" + "="*50)
    print(Fore.BLUE + Style.BRIGHT + "Analysis complete! 🚀" + Style.RESET_ALL)