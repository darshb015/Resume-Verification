📊 Automated Stock Data Pipeline & Pair Trading Strategy
📌 Project Overview
This project automates the entire lifecycle of stock data collection, cleaning, consolidation, and analysis for Indian stock markets.
The pipeline downloads Nifty 50 constituent data, organizes it, merges into a single structured dataset, and applies statistical pair trading analysis to identify trading opportunities.
The project demonstrates skills in:
Web Scraping (Selenium, Requests)
Data Engineering (CSV → Excel pipeline)
Statistical Analysis (Correlation & Cointegration)
Automation with Python
Progress tracking & error handling with logs/colors

⚙️ Workflow
1. Download Nifty 50 Constituents
Script: download_nifty50_list.py
Downloads the latest Nifty 50 constituent list (CSV) from NSE official index site.
Ensures clean storage in project’s download directory.

2. Historical Stock Data Scraper
Script: nse_historical_scraper.py
Uses Selenium with Chrome automation to fetch 1-year historical data for each Nifty 50 stock from NSE’s website.
Downloads data as CSV files into a structured folder.
Tracks success & failure logs with real-time progress bars.

3. Data Consolidation & Cleaning
Script: combine_stock_data.py
Reads all stock CSVs.
Normalizes dates (fixes inconsistent formats).
Merges into a single Excel file (Combined Nifty100 Stocks Data.xlsx) with:
Dates as rows
Stocks as columns
Ensures missing values are marked "N/A" for transparency.

4. Pair Trading Analysis
Script: pair_trading_analysis.py
Loads the consolidated dataset.
Applies Correlation + Cointegration tests to identify pairs of stocks with strong statistical relationships.
Filters based on configurable thresholds:
Minimum correlation (default = 0.8)
Maximum cointegration p-value (default = 0.05)
Exports results as pair_trading_candidates.csv and prints Top 20 Pairs with color-coded scores for readability.

📂 Project Structure
Main/
│── 📁 Downloads/                 # (Empty at first) Will store all downloaded data & results
│
│── Stocks_Download.py            # Step 1: Download Nifty50 stock data
│── Combine_Data.py               # Step 2: Merge stock CSVs into one file
│── Pairs.py                      # Step 3: Run pair trading analysis


🛠️ Tech Stack
Python Libraries:
requests, selenium, pandas, numpy, statsmodels, openpyxl, tqdm, colorama
Automation Tools: Selenium WebDriver (Chrome)
Data Formats: CSV & Excel

🚀 How to Run

You can run the project in two ways:

🔹 Option 1: Run on Google Colab (Recommended ✅)
Open the notebook in Google Colab.
Run the cells step by step (dependencies auto-installed).
No local setup required.
All outputs (CSV/Excel) will be saved in the Downloads/ folder inside the runtime.

🔹 Option 2: Run Locally
1️⃣ Clone Repository & Install Requirements
git clone https://github.com/<your-username>/<repo-name>.git
cd <repo-name>


👉 Execution Order:
1️⃣ Run Stocks_Download.py → saves raw stock data into Downloads/
2️⃣ Run Combine_Data.py → generates merged dataset inside Downloads/
3️⃣ Run Pairs.py → produces pair trading results inside Downloads/


📈 Example Output (Top Pair Trading Candidates)
Stock 1	Stock 2	Correlation	Cointegration (p-value)
HDFC	ICICI	0.9452 ✅	0.0032 ✅
INFY	TCS	0.9128 ✅	0.0121 ✅

(✅ indicates strong pair-trading candidate)

🌟 Key Highlights
✔ End-to-End Automation – From raw data fetching to cleaned dataset & trading insights.
✔ Error Handling & Logging – Retry logic, timeouts, success/failure reports.
✔ Scalable Framework – Can be extended to Nifty 100 / 500 stocks.
✔ Practical Finance Use-Case – Implements quantitative finance methods used in real-world trading.