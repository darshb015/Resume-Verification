import csv
from datetime import datetime
from openpyxl import Workbook
from pathlib import Path
import os
import sys
from tqdm import tqdm
import time

def print_banner():
    print("\033[1;36m")
    print("**********************************************")
    print("*    STOCK DATA COMBINER - NIFTY 500        *")
    print("**********************************************")
    print("\033[0m")

def read_stock_data(file_path, stock_name):
    """Reads a stock CSV file and returns a dict of {normalized_date: close_price}"""
    data = {}
    with open(file_path, mode='r', encoding='utf-8-sig') as csv_file:
        csv_reader = csv.DictReader(csv_file)
        for row in csv_reader:
            # Strip whitespace from column names and values
            row = {k.strip(): v.strip() for k, v in row.items()}
            
            date_str = row['Date']
            # Normalize date format (e.g., "01-Apr-25" → "01-Apr-2025")
            try:
                date_obj = datetime.strptime(date_str, "%d-%b-%y")
                normalized_date = date_obj.strftime("%d-%b-%Y")
            except ValueError:
                normalized_date = date_str
            
            close_price = row['close'].replace(',', '')
            data[normalized_date] = float(close_price)
    return data

def extract_stock_name(filename):
    """Extracts stock name from filename pattern"""
    base_name = os.path.splitext(filename)[0]
    parts = base_name.split('-')
    
    try:
        equity_index = parts.index("Equity") if "Equity" in parts else parts.index("EQUITY")
        eq_index = parts.index("EQ") if "EQ" in parts else parts.index("eq")
        if eq_index > equity_index + 1:
            return parts[equity_index + 1]
    except ValueError:
        pass
    
    for i, part in enumerate(parts):
        if part.upper() == "EQ":
            return parts[i-1] if i > 0 else base_name
    
    return base_name

def main():
    print_banner()
    
    # Prepare paths
    input_dir = Path(r"Main\Downloads\Nifty50")
    output_dir = Path(r"Main\Downloads")
    output_dir.mkdir(parents=True, exist_ok=True)
    output_file = output_dir / "Combined Nifty100 Stocks Data.xlsx"

    # Get all CSV files
    csv_files = list(input_dir.glob('*.csv'))
    if not csv_files:
        print("\033[1;31mNo CSV files found in the input directory!\033[0m")
        return

    print(f"\033[1;32mFound {len(csv_files)} stock data files to process\033[0m")
    print("\033[1;33mProcessing files...\033[0m")

    # Initialize data storage
    all_data = {}
    stock_names = []
    date_set = set()

    # Process files with progress bar
    for csv_file in tqdm(csv_files, desc="Processing Stocks", unit="file", colour='green'):
        stock_name = extract_stock_name(csv_file.name)
        stock_names.append(stock_name)
        all_data[stock_name] = read_stock_data(csv_file, stock_name)
        date_set.update(all_data[stock_name].keys())
        time.sleep(0.02)  # For smooth progress bar animation

    # Sort dates chronologically
    sorted_dates = sorted(date_set, key=lambda x: datetime.strptime(x, "%d-%b-%Y"))

    # Create Excel workbook
    print("\n\033[1;33mCreating Excel workbook...\033[0m")
    wb = Workbook()
    ws = wb.active
    ws.title = "Combined Stock Data"

    # Write headers
    ws['A1'] = "Date"
    for col_num, stock_name in enumerate(stock_names, start=2):
        ws.cell(row=1, column=col_num, value=stock_name)

    # Write data with progress bar
    for row_num, date in enumerate(tqdm(sorted_dates, desc="Writing Data", unit="row", colour='blue'), start=2):
        ws.cell(row=row_num, column=1, value=date)
        for col_num, stock_name in enumerate(stock_names, start=2):
            ws.cell(row=row_num, column=col_num, value=all_data[stock_name].get(date, "N/A"))

    # Save the workbook
    wb.save(output_file)
    
    # Final output
    print("\n\033[1;32m✓ Successfully completed!\033[0m")
    print(f"\033[1;34mOutput file saved to:\033[0m \033[1;35m{output_file}\033[0m")
    print(f"\033[1;34mTotal stocks processed:\033[0m \033[1;35m{len(stock_names)}\033[0m")
    print(f"\033[1;34mDate range covered:\033[0m \033[1;35m{sorted_dates[0]} to {sorted_dates[-1]}\033[0m")

if __name__ == "__main__":
    main()