Automated Financial Data Collection and Gold Price Forecasting using Machine Learning
📌 Project Overview
This project integrates automated financial data collection with machine learning-based forecasting to analyze and predict gold prices.
Data Collection: Automated scraping of historical stock and commodity data (Nifty 50, Nifty 100, Nifty 500, MCX) using Selenium.
Data Preprocessing: Consolidation of multiple CSV files into a single Excel sheet, aligned by date.
Machine Learning: Training a Random Forest Regressor to forecast gold prices with high accuracy.

🛠️ Features
Automated web scraping of financial data from NSE & MCX.
Smart handling of downloads and data cleaning.
Combines all stock CSVs into a chronologically ordered Excel file.
Exploratory data analysis with correlation heatmaps and distribution plots.
Random Forest Regressor model with GridSearchCV hyperparameter tuning.
Visualization of actual vs predicted gold prices.

📂 Project Structure
│
├── 📁 Gold Price ML
│   │── gold_price_data.csv      # Gold price dataset
│   │── gold.py                  # ML model for gold price prediction
│
├── 📁 Stocks
│   │── Stocks_Download.py       # Selenium script to download stock data
│   │── 📁 Downloads            # Folder to store all downloaded CSV files
│
└── README.md                   # Project documentation

🚀 How to Run

You can run the project in two ways:

🔹 Option 1: Run on Google Colab (Recommended ✅)
A Google Colab notebook is provided for easier execution.
Open the notebook in Colab.
Run the cells step by step.
All dependencies will be installed automatically.
No local setup required.

🔹 Option 2: Run Locally
Clone the Repository
git clone https://github.com/<your-username>/<repo-name>.git
cd <repo-name>

Install Dependencies
pip install numpy pandas matplotlib seaborn scikit-learn xgboost tqdm colorama openpyxl selenium

Run the Stock Data Downloader
python Stocks/Stocks_Download.py

👉 Downloads all stock CSVs into the Stocks/Downloads/ folder.
Combine Stock Data
python data_combiner.py

👉 Generates: Combined Nifty50 Stocks Data.xlsx
Train Gold Price Forecasting Model
python "Gold Price ML/gold.py"


📊 Results
Achieved strong predictive performance using Random Forest Regressor.
Hyperparameter tuning with GridSearchCV improved accuracy.
Forecast visualization showed good alignment between predicted and actual gold prices.

🧰 Technologies Used
Web Scraping: Selenium, TQDM, Colorama
Data Handling: Pandas, OpenPyXL, NumPy
Visualization: Matplotlib, Seaborn
Machine Learning: Scikit-learn (RandomForestRegressor, GridSearchCV)

