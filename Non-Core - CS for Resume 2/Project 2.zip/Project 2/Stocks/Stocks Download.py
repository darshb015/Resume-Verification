import os
import time
from tqdm import tqdm
from colorama import Fore, Style, init
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

# Init colorama
init(autoreset=True)

# Paths
download_dir = r"C:\Users\darsh\Documents\Stock Market\Main\Downloads\Nifty100"

# Only download these symbols
symbols = [
    "RELIANCE",
    "HDFCBANK",
    "BHARTIARTL",
    "TCS",
    "ICICIBANK",
    "SBIN",
    "INFY",
    "HINDUNILVR",
    "BAJFINANCE",
    "ITC",
    "MCX"
]

# Chrome options
options = Options()
options.add_argument("--start-maximized")
options.add_argument("--disable-blink-features=AutomationControlled")
options.add_experimental_option("excludeSwitches", ["enable-automation"])
options.add_experimental_option('useAutomationExtension', False)
options.add_argument("user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                     "AppleWebKit/537.36 (KHTML, like Gecko) "
                     "Chrome/122.0.0.0 Safari/537.36")

prefs = {
    "download.default_directory": download_dir,
    "download.prompt_for_download": False,
    "download.directory_upgrade": True,
    "safebrowsing.enabled": True
}
options.add_experimental_option("prefs", prefs)

# Helper: wait until downloads complete
def wait_for_downloads(path, timeout=15):
    end_time = time.time() + timeout
    while time.time() < end_time:
        if not any(fname.endswith(".crdownload") for fname in os.listdir(path)):
            return True
        time.sleep(0.5)
    return False

# Launch driver
driver = webdriver.Chrome(options=options)
wait = WebDriverWait(driver, 10)

# Results tracking
success_list = []
failed_list = []

try:
    print(Fore.CYAN + f"\nStarting downloads for {len(symbols)} symbols...\n")
    for symbol in tqdm(symbols, desc="Processing", unit="symbol"):
        try:
            url = f"https://www.nseindia.com/get-quotes/equity?symbol={symbol}"
            driver.get(url)

            # Interact with elements
            historical_section = wait.until(EC.element_to_be_clickable((By.ID, "historic_data")))
            driver.execute_script("arguments[0].scrollIntoView(true);", historical_section)
            historical_section.click()

            one_year_btn = wait.until(EC.element_to_be_clickable((By.ID, "oneY")))
            one_year_btn.click()

            download_btn = wait.until(EC.element_to_be_clickable((By.ID, "dwldcsv")))
            download_btn.click()

            # Wait for download
            if wait_for_downloads(download_dir):
                print(Fore.GREEN + f"✔ Downloaded: {symbol}")
                success_list.append(symbol)
            else:
                print(Fore.YELLOW + f"⚠ Timeout: {symbol}")
                failed_list.append(symbol)

            time.sleep(1)  # brief pause
        except Exception as e:
            print(Fore.RED + f"✖ Failed: {symbol} | Reason: {str(e).splitlines()[0]}")
            failed_list.append(symbol)

finally:
    driver.quit()

# Summary Report
print(Fore.MAGENTA + "\n" + "=" * 60)
print(Fore.BLUE + Style.BRIGHT + "Download Summary")
print(Fore.MAGENTA + "=" * 60)
print(Fore.GREEN + f"✔ Successfully downloaded: {len(success_list)} symbols")
print(Fore.RED + f"✖ Failed downloads: {len(failed_list)} symbols")

if failed_list:
    print(Fore.YELLOW + "\nFailed symbols:")
    for sym in failed_list:
        print(f" - {sym}")
    